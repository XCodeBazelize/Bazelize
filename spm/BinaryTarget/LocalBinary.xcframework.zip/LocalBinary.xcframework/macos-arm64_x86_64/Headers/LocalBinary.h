#ifndef LOCAL_BINARY_H
#define LOCAL_BINARY_H

int local_binary_value(void);

#endif
